
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
class Room implements Comparable<Room> {
    private int roomNo;
    private double price;
    public Room(int roomNo, double price) {
        this.roomNo = roomNo;
        this.price = price;
    }
    public double getPrice() {
        return price;
    }
    public int getRoomNo() {
        return roomNo;
    }
    public String getRoomInfo() {
        return "";
    }
    @Override
    public int compareTo(Room o) {
        return Double.compare(this.getPrice(), o.getPrice());
    }
}
class SingleRoom extends Room {
    private String bedType;
    private boolean smoking;
    public SingleRoom(int roomNo, double price, String bedType, boolean smoking) {
        super(roomNo, price);
        this.bedType = bedType;
        this.smoking = smoking;
    }
    @Override
    public String getRoomInfo() {
        String info = super.getRoomInfo() + "\t$" + super.getPrice() + "\t\t" + bedType + "\t\t";
        if (smoking)
            return info + "Smoking" + "\n";
        else
            return info + "No Smoking" + "\n";
    }
}
class Suite extends Room {
    private int numRoom;
    private boolean hasKitchen;
    private int rating;
    public Suite(int roomNo, double price, int rating, boolean hasKitchen, int numRoom) {
        super(roomNo, price);
        this.rating = rating;
        this.hasKitchen = hasKitchen;
        this.numRoom = numRoom;
    }
    @Override
    public String getRoomInfo() {
        String info = super.getRoomInfo() + "\t$" + super.getPrice() + "\t\t" + rating + "\t\t";
        if (hasKitchen)
            return info + "With Kitchen" + "\n";
        else
            return info + "No Kitchen" + "\n";
    }
    public int getRating() {
        return rating;
    }
}
public class HotelProject {
    public static void main(String[] args) {
        List<SingleRoom> roomList = new ArrayList<>();
        roomList.add(new SingleRoom(1, 140.5, "Queen", true));
        roomList.add(new SingleRoom(2, 130.5, "Twin", false));
        roomList.add(new SingleRoom(3, 150.5, "King", true));
        List<Suite> suiteList = new ArrayList<>();
        suiteList.add(new Suite(4, 600, 5, true, 4));
        suiteList.add(new Suite(5, 800, 5, false, 5));
        suiteList.add(new Suite(6, 500, 3, false, 2));
        Collections.sort(roomList);
        Collections.sort(suiteList);
        System.out.println("Hotel Information:");
        System.out.println("Room No\tPrice\t\tBed Type\tSmoking Status");
        for (SingleRoom room : roomList) {
            System.out.print(room.getRoomNo() + "\t\t");
            System.out.print("$" + room.getPrice() + "\t\t");
            System.out.print(room.getRoomInfo());
        }
        System.out.println("\n\nSuite Information:");
        System.out.println("Room No\tPrice\t\tRating\tKitchen");
        for (Suite suite : suiteList) {
            System.out.print(suite.getRoomNo() + "\t\t");
            System.out.print("$" + suite.getPrice() + "\t\t");
            System.out.print(suite.getRating() + "\t\t");
            System.out.print(suite.getRoomInfo());
        }
    }
}
